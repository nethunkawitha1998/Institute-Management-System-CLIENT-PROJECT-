﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace teachermanagement
{
    public partial class Form1 : Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=classmanagement;Integrated Security=True;Pooling=False");


        public Form1()
        {
            InitializeComponent();
        }

        private void Addbutton_Click(object sender, EventArgs e)
        {


            if (idbox.Text == "" || namebox.Text == "" || emailbox.Text == "" || schoolbox.Text == "" || addressbox.Text == "" || subject1box.Text == "" || gradebox.Text == "")
            {

                MessageBox.Show("Fill All Fields");


            }
            else
            {
                connection.Open();
                SqlCommand cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into [Table108] (TeacherID,TeacherName,Email,School,Address,Subject1,Grade) values ('" + idbox.Text + "','" + namebox.Text + "','" + emailbox.Text + "','" + schoolbox.Text + "','" + addressbox.Text + "','" + subject1box.Text + "','" + gradebox.Text + "')";
                cmd.ExecuteNonQuery();
                connection.Close();

                idbox.Text = "";
                namebox.Text = "";
                emailbox.Text = "";
                schoolbox.Text = "";
                addressbox.Text = "";
                subject1box.Text = "";
                gradebox.Text = "";

                MessageBox.Show("Added Successfully!");
                display_data();


            }
        }



        //To Display Data
        public void display_data()
        {

            connection.Open();
            SqlCommand cmd = connection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from [Table108]";
            cmd.ExecuteNonQuery();
            DataTable dta = new DataTable();
            SqlDataAdapter dataadp = new SqlDataAdapter(cmd);
            dataadp.Fill(dta);
            dataGridView1.DataSource = dta;
            connection.Close();
        }

        private void Displaybutton_Click(object sender, EventArgs e)
        {
            display_data();
        }



        private void DataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            idbox.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            namebox.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            emailbox.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            schoolbox.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            addressbox.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            subject1box.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            gradebox.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
        }

        private void Deletebutton_Click(object sender, EventArgs e)
        {
            if (idbox.Text == "")
            {

                MessageBox.Show("Fields are empty ! Insert Teacher's ID that want to delete");


            }
            else
            {





                connection.Open();
                SqlCommand cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from [Table108] where TeacherID = '" + idbox.Text + "'";
                cmd.ExecuteNonQuery();
                connection.Close();

                display_data();

                MessageBox.Show("Delete Successfully!");

                idbox.Text = "";
                namebox.Text = "";
                emailbox.Text = "";
                schoolbox.Text = "";
                addressbox.Text = "";
                subject1box.Text = "";
                gradebox.Text = "";
            }
        }

        private void Updatebutton_Click(object sender, EventArgs e)
        {

            if (idbox.Text == "")
            {

                MessageBox.Show("Fields are empty ! Insert Teacher's ID that want to delete");


            }
            else
            {


                connection.Open();
                SqlCommand cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update [Table108] set TeacherID = '" + idbox.Text + "' ,TeacherName = '" + namebox.Text + "',Email = '" + emailbox.Text + "',School = '" + schoolbox.Text + "',Address = '" + addressbox.Text + "',Subject1 = '" + subject1box.Text + "',Grade = '" + gradebox.Text + "'";
                cmd.ExecuteNonQuery();
                connection.Close();

                idbox.Text = "";
                namebox.Text = "";
                emailbox.Text = "";
                schoolbox.Text = "";
                addressbox.Text = "";
                subject1box.Text = "";
                gradebox.Text = "";
                display_data();

                MessageBox.Show("Update Successfully!");
            }
        }

        private void Searchclassbox_SelectedIndexChanged(object sender, EventArgs e)
        {

            connection.Open();
            SqlCommand cmd = connection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from [Table108] where Grade = '" + searchclassbox.Text + "' and Subject1 = '" + searchsubjectbox.Text + "' ";
            cmd.ExecuteNonQuery();
            DataTable dta = new DataTable();
            SqlDataAdapter dataadp = new SqlDataAdapter(cmd);
            dataadp.Fill(dta);
            dataGridView1.DataSource = dta;
            connection.Close();



        }

        private void Searchsubjectbox_SelectedIndexChanged(object sender, EventArgs e)
        {


            connection.Open();
            SqlCommand cmd = connection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from [Table108] where Grade = '" + searchclassbox.Text + "' and Subject1 = '" + searchsubjectbox.Text + "' ";
            cmd.ExecuteNonQuery();
            DataTable dta = new DataTable();
            SqlDataAdapter dataadp = new SqlDataAdapter(cmd);
            dataadp.Fill(dta);
            dataGridView1.DataSource = dta;
            connection.Close();

        }
    }
}

