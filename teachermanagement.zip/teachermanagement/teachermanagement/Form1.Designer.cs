﻿namespace teachermanagement
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.idbox = new System.Windows.Forms.TextBox();
            this.namebox = new System.Windows.Forms.TextBox();
            this.emailbox = new System.Windows.Forms.TextBox();
            this.schoolbox = new System.Windows.Forms.TextBox();
            this.addressbox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.addbutton = new System.Windows.Forms.Button();
            this.updatebutton = new System.Windows.Forms.Button();
            this.deletebutton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.displaybutton = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.gradebox = new System.Windows.Forms.ComboBox();
            this.searchclassbox = new System.Windows.Forms.ComboBox();
            this.subject1box = new System.Windows.Forms.ComboBox();
            this.searchsubjectbox = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Teacher\'s ID ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(46, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 202);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(46, 260);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "School";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(46, 325);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Address";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(46, 391);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Subject 1";
            // 
            // idbox
            // 
            this.idbox.Location = new System.Drawing.Point(137, 71);
            this.idbox.Name = "idbox";
            this.idbox.Size = new System.Drawing.Size(229, 20);
            this.idbox.TabIndex = 7;
            // 
            // namebox
            // 
            this.namebox.Location = new System.Drawing.Point(137, 137);
            this.namebox.Name = "namebox";
            this.namebox.Size = new System.Drawing.Size(229, 20);
            this.namebox.TabIndex = 8;
            // 
            // emailbox
            // 
            this.emailbox.Location = new System.Drawing.Point(137, 199);
            this.emailbox.Name = "emailbox";
            this.emailbox.Size = new System.Drawing.Size(229, 20);
            this.emailbox.TabIndex = 9;
            // 
            // schoolbox
            // 
            this.schoolbox.Location = new System.Drawing.Point(137, 257);
            this.schoolbox.Name = "schoolbox";
            this.schoolbox.Size = new System.Drawing.Size(229, 20);
            this.schoolbox.TabIndex = 10;
            // 
            // addressbox
            // 
            this.addressbox.Location = new System.Drawing.Point(137, 322);
            this.addressbox.Name = "addressbox";
            this.addressbox.Size = new System.Drawing.Size(229, 20);
            this.addressbox.TabIndex = 11;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(572, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(196, 20);
            this.label8.TabIndex = 14;
            this.label8.Text = "Teacher\'s Management";
            // 
            // addbutton
            // 
            this.addbutton.Location = new System.Drawing.Point(614, 512);
            this.addbutton.Name = "addbutton";
            this.addbutton.Size = new System.Drawing.Size(104, 41);
            this.addbutton.TabIndex = 15;
            this.addbutton.Text = "Add";
            this.addbutton.UseVisualStyleBackColor = true;
            this.addbutton.Click += new System.EventHandler(this.Addbutton_Click);
            // 
            // updatebutton
            // 
            this.updatebutton.Location = new System.Drawing.Point(788, 512);
            this.updatebutton.Name = "updatebutton";
            this.updatebutton.Size = new System.Drawing.Size(104, 41);
            this.updatebutton.TabIndex = 16;
            this.updatebutton.Text = "Update";
            this.updatebutton.UseVisualStyleBackColor = true;
            this.updatebutton.Click += new System.EventHandler(this.Updatebutton_Click);
            // 
            // deletebutton
            // 
            this.deletebutton.Location = new System.Drawing.Point(967, 512);
            this.deletebutton.Name = "deletebutton";
            this.deletebutton.Size = new System.Drawing.Size(104, 41);
            this.deletebutton.TabIndex = 17;
            this.deletebutton.Text = "Delete";
            this.deletebutton.UseVisualStyleBackColor = true;
            this.deletebutton.Click += new System.EventHandler(this.Deletebutton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(435, 99);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(846, 379);
            this.dataGridView1.TabIndex = 18;
            this.dataGridView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.DataGridView1_MouseDoubleClick);
            // 
            // displaybutton
            // 
            this.displaybutton.Location = new System.Drawing.Point(435, 71);
            this.displaybutton.Name = "displaybutton";
            this.displaybutton.Size = new System.Drawing.Size(75, 23);
            this.displaybutton.TabIndex = 19;
            this.displaybutton.Text = "View All";
            this.displaybutton.UseVisualStyleBackColor = true;
            this.displaybutton.Click += new System.EventHandler(this.Displaybutton_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(46, 460);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "Grade";
            // 
            // gradebox
            // 
            this.gradebox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.gradebox.FormattingEnabled = true;
            this.gradebox.Items.AddRange(new object[] {
            "6",
            "7",
            "8",
            "9",
            "10",
            "11"});
            this.gradebox.Location = new System.Drawing.Point(137, 457);
            this.gradebox.Name = "gradebox";
            this.gradebox.Size = new System.Drawing.Size(229, 21);
            this.gradebox.TabIndex = 21;
            // 
            // searchclassbox
            // 
            this.searchclassbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.searchclassbox.FormattingEnabled = true;
            this.searchclassbox.Items.AddRange(new object[] {
            "6",
            "7",
            "8",
            "9",
            "10",
            "11"});
            this.searchclassbox.Location = new System.Drawing.Point(739, 71);
            this.searchclassbox.Name = "searchclassbox";
            this.searchclassbox.Size = new System.Drawing.Size(121, 21);
            this.searchclassbox.TabIndex = 24;
            this.searchclassbox.SelectedIndexChanged += new System.EventHandler(this.Searchclassbox_SelectedIndexChanged);
            // 
            // subject1box
            // 
            this.subject1box.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.subject1box.FormattingEnabled = true;
            this.subject1box.Items.AddRange(new object[] {
            "Maths",
            "Sinhala",
            "Science",
            "English",
            "Tamil",
            "History",
            "Commerce"});
            this.subject1box.Location = new System.Drawing.Point(137, 388);
            this.subject1box.Name = "subject1box";
            this.subject1box.Size = new System.Drawing.Size(229, 21);
            this.subject1box.TabIndex = 25;
            // 
            // searchsubjectbox
            // 
            this.searchsubjectbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.searchsubjectbox.FormattingEnabled = true;
            this.searchsubjectbox.Items.AddRange(new object[] {
            "Maths",
            "Sinhala",
            "Science",
            "English",
            "Tamil",
            "History",
            "Commerce"});
            this.searchsubjectbox.Location = new System.Drawing.Point(953, 71);
            this.searchsubjectbox.Name = "searchsubjectbox";
            this.searchsubjectbox.Size = new System.Drawing.Size(121, 21);
            this.searchsubjectbox.TabIndex = 27;
            this.searchsubjectbox.SelectedIndexChanged += new System.EventHandler(this.Searchsubjectbox_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(697, 74);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 13);
            this.label7.TabIndex = 28;
            this.label7.Text = "Grade";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(904, 74);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 13);
            this.label10.TabIndex = 29;
            this.label10.Text = "Subject";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1330, 604);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.searchsubjectbox);
            this.Controls.Add(this.subject1box);
            this.Controls.Add(this.searchclassbox);
            this.Controls.Add(this.gradebox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.displaybutton);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.deletebutton);
            this.Controls.Add(this.updatebutton);
            this.Controls.Add(this.addbutton);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.addressbox);
            this.Controls.Add(this.schoolbox);
            this.Controls.Add(this.emailbox);
            this.Controls.Add(this.namebox);
            this.Controls.Add(this.idbox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox idbox;
        private System.Windows.Forms.TextBox namebox;
        private System.Windows.Forms.TextBox emailbox;
        private System.Windows.Forms.TextBox schoolbox;
        private System.Windows.Forms.TextBox addressbox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button addbutton;
        private System.Windows.Forms.Button updatebutton;
        private System.Windows.Forms.Button deletebutton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button displaybutton;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox gradebox;
        private System.Windows.Forms.ComboBox searchclassbox;
        private System.Windows.Forms.ComboBox subject1box;
        private System.Windows.Forms.ComboBox searchsubjectbox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
    }
}

